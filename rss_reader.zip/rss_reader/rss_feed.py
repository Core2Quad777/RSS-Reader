import feedparser as fp
import schedule
# a list of links from which RSS is streamed. !!! MAKE SURE THE SITE YOU WANT IS RSS ENABLED!!!
urls = [ ] # вставьте ссылки на требуемые сайты

latest_titles = [] # list of new headers, see README for behaviour
latest_links = []  # list of new links, see README for behaviour
def get_latest_articles(urls, latest_links, latest_titles):

    for url in urls:
        parsed_feed = fp.parse(url)
        for entry in parsed_feed.entries:
            latest_titles.append(entry.title)
            latest_links.append(entry.link)

    return latest_titles, latest_links


old_titles = [] # list of old headers, see README for behaviour
old_links = []  # list of old links, see README for behaviour
def get_old_articles(urls, old_titles, old_links):

    for url in urls:
        parsed_feed = fp.parse(url)
        for entry in parsed_feed.entries:
            old_titles.append(entry.title)
            old_links.append(entry.link)

    return old_titles, old_links


titles, links = get_latest_articles(urls, latest_links, latest_titles)
old_titles, old_links = get_old_articles(urls, old_titles, old_links)


# function that checks for duplicate entries, see README for details
def isChange(titles, links, old_titles, old_links):
    title = []
    link = []
    title.append(list(set(titles).difference(set(old_titles))))
    link.append(list(set(links).difference(set(old_links))))

    try:
        text = f'{title[0][0:]} /n {link[0][0:]}'
    except IndexError:
        pass

    return title, link, text

title, link, text = isChange(titles, links, old_titles, old_links)


def clean_new(titles, links,):
    titles.clear()
    links.clear()


def clean_old(old_titles, old_links):
    old_titles.clear()
    old_links.clear()


schedule.every(10).minutes.do(get_latest_articles, sites, latest_links, latest_titles ) # getting new data
schedule.every(60).minutes.do(get_old_articles, sites, old_titles, old_links) # old data, as you can see it is updated later
schedule.every(60).minutes.do(clean_old, old_titles, old_links) # clearing old lists
schedule.every(10).minutes.do(isChange, titles, links, old_titles, old_links) # check for changes in lists
schedule.every(10).minutes.do(clean_new, titles, links) # clearing new lists

while True:
    schedule.run_pending()